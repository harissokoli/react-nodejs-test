import './style.css';
const Spinner = () => <div className="loader"></div>;

export default Spinner;